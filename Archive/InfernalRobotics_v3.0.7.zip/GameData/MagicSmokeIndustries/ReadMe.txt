﻿All credit to Damned Robotics goes to:
Plugin/lots of stuff : r4m0n
3dmodels/'textures' : DYJ

original source location: http://svn.mumech.com/KSP/trunk/MuMechLib/

All new 3dmodels & textures : sirkut, Devo, ZodiusInfuser